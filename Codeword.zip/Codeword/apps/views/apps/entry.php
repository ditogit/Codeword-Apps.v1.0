
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, shrink-to-fit=no">
        <title>Codeword</title>
        <link rel="icon" type="image/x-icon" href="<?= base_url(); ?>resource/assets/img/favicon.ico"/>
        <!-- BEGIN GLOBAL MANDATORY STYLES -->
        <link href="https://fonts.googleapis.com/css?family=Nunito:400,600,700" rel="stylesheet">
        <link href="<?= base_url(); ?>resource/bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
        <link href="<?= base_url(); ?>resource/assets/css/plugins.css" rel="stylesheet" type="text/css" />
        <!-- END GLOBAL MANDATORY STYLES -->
        <!-- BEGIN PAGE LEVEL CUSTOM STYLES -->
        <link href="<?= base_url(); ?>resource/assets/css/scrollspyNav.css" rel="stylesheet" type="text/css" />
        <link rel="stylesheet" type="text/css" href="<?= base_url(); ?>resource/assets/css/forms/theme-checkbox-radio.css">
        <link href="<?= base_url(); ?>resource/assets/css/tables/table-basic.css" rel="stylesheet" type="text/css" />
        <!-- END PAGE LEVEL CUSTOM STYLES -->
        <script>
            var base_url = '<?= base_url() ?>';
        </script>
    </head>
    <body class="sidebar-noneoverflow" data-spy="scroll" data-target="#navSection" data-offset="140">

        <!--  BEGIN NAVBAR  -->
        <div class="header-container fixed-top">
            <header class="header navbar navbar-expand-sm">
                <a href="javascript:void(0);" class="sidebarCollapse" data-placement="bottom"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-menu"><line x1="3" y1="12" x2="21" y2="12"></line><line x1="3" y1="6" x2="21" y2="6"></line><line x1="3" y1="18" x2="21" y2="18"></line></svg></a>
                <ul class="navbar-item flex-row search-ul">
                    <li class="nav-item align-self-center search-animated">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-search toggle-search"><circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line></svg>
                        <form class="form-inline search-full form-inline search" role="search">
                            <div class="search-bar">
                                <input type="text" class="form-control search-form-control  ml-lg-auto" placeholder="Search...">
                            </div>
                        </form>
                    </li>
                </ul>
                <ul class="navbar-item flex-row navbar-dropdown"> 
                    <li class="nav-item dropdown user-profile-dropdown  order-lg-0 order-1">
                        <a href="javascript:void(0);" class="nav-link dropdown-toggle user" id="userProfileDropdown" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-user"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path><circle cx="12" cy="7" r="4"></circle></svg>
                        </a> 
                    </li>
                </ul>
            </header>
        </div>
        <!--  END NAVBAR  -->

        <!--  BEGIN MAIN CONTAINER  -->
        <div class="main-container" id="container">

            <div class="overlay"></div>
            <div class="cs-overlay"></div>
            <div class="search-overlay"></div>

            <!--  BEGIN SIDEBAR  -->
            <div class="sidebar-wrapper sidebar-theme">

                <nav id="sidebar">

                    <ul class="navbar-nav theme-brand flex-row  text-center"> 
                        <li class="nav-item theme-text">
                            <a href="index.html" class="nav-link"> CODEWORD </a>
                        </li> 
                    </ul>

                    <div class="shadow-bottom"></div>
                    <ul class="list-unstyled menu-categories" id="accordionExample"> 

                        <li class="menu menu-heading">
                            <div class="heading"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-circle"><circle cx="12" cy="12" r="10"></circle></svg><span>Apps</span></div>
                        </li>

                        <li class="menu">
                            <a href="<?= base_url('home') ?>" class="dropdown-toggle">
                                <div class="">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-cpu"><rect x="4" y="4" width="16" height="16" rx="2" ry="2"></rect><rect x="9" y="9" width="6" height="6"></rect><line x1="9" y1="1" x2="9" y2="4"></line><line x1="15" y1="1" x2="15" y2="4"></line><line x1="9" y1="20" x2="9" y2="23"></line><line x1="15" y1="20" x2="15" y2="23"></line><line x1="20" y1="9" x2="23" y2="9"></line><line x1="20" y1="14" x2="23" y2="14"></line><line x1="1" y1="9" x2="4" y2="9"></line><line x1="1" y1="14" x2="4" y2="14"></line></svg>
                                    <span>Vocabulary</span>
                                </div>
                            </a>
                        </li>                         
                        <li class="menu active">
                            <a href="<?= base_url('home/entry') ?>" aria-expanded="true"  class="dropdown-toggle">
                                <div class="">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-layers"><polygon points="12 2 2 7 12 12 22 7 12 2"></polygon><polyline points="2 17 12 22 22 17"></polyline><polyline points="2 12 12 17 22 12"></polyline></svg>
                                    <span>Entry Symbol</span>
                                </div>
                            </a>
                        </li>                         

                    </ul>
                </nav>
            </div>
            <!--  END SIDEBAR  -->

            <!--  BEGIN CONTENT AREA  -->
            <div id="content" class="main-content">
                <div class="layout-px-spacing">
                    <div class="container">
                        <div class="row layout-top-spacing">   
                            <div class="col-lg-12 col-12 layout-spacing">
                                <div class="statbox widget box box-shadow">
                                    <div class="widget-header">
                                        <div class="row">
                                            <div class="col-xl-12 col-md-12 col-sm-12 col-12">
                                                <h4>Entry String</h4>
                                            </div>                       
                                        </div>
                                    </div>
                                    <div class="widget-content widget-content-area">
                                        <form method="post" action="<?= base_url('home/entry') ?>" autocomplete="off">
                                            <div class="form-row mb-4">
                                                <div class="col-md-5">
                                                    <input type="text" name="data" class="form-control form-control-sm symbol" placeholder="nama/nim">
                                                    <div class="help-block ms-symbol"></div>
                                                </div> 
                                                <div class="col-md-3">
                                                    <button type="submit" name="save" value="encode" class=" btn btn-primary">Encode</button>
                                                </div>
                                            </div>                                        
                                        </form>
                                        <button onclick="window.location='<?= base_url('home/entry'); ?>'" name="clear" class="mb-4 btn btn-warning">Clear</button>
                                        <div class="table-responsive">
                                            <table class="table table-bordered table-hover  table-checkable table-highlight-head mb-4">
                                                <thead>
                                                    <tr> 
                                                        <th class="">Symbol</th>
                                                        <th class="">Binary</th> 
                                                    </tr>
                                                </thead>
                                                <tbody> 
                                                    <?= $html; ?>
                                                    <?= $temp; ?>
                                                </tbody>
                                            </table>
                                        </div> 
                                    </div>
                                </div>
                            </div> 

                        </div> 
                    </div> 
                </div>
                <div class="footer-wrapper">
                    <div class="footer-section f-section-1">
                        <p class="">Copyright © 2020 <a target="_blank" href="https://designreset.com">DesignReset</a>, All rights reserved.</p>
                    </div>
                    <div class="footer-section f-section-2">
                        <p class="">Coded with <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-heart"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"></path></svg></p>
                    </div>
                </div>
            </div>
            <!--  END CONTENT AREA  -->

        </div>
        <!-- END MAIN CONTAINER -->

        <!-- BEGIN GLOBAL MANDATORY SCRIPTS -->
        <script src="<?= base_url(); ?>resource/assets/js/libs/jquery-3.1.1.min.js"></script>
        <script src="<?= base_url(); ?>resource/bootstrap/js/popper.min.js"></script>
        <script src="<?= base_url(); ?>resource/bootstrap/js/bootstrap.min.js"></script>
        <script src="<?= base_url(); ?>resource/plugins/perfect-scrollbar/perfect-scrollbar.min.js"></script>
        <script src="<?= base_url(); ?>resource/assets/js/app.js"></script>

        <script>
            $(document).ready(function() {
                App.init();
                $(".check-prefix").click(function(){
                    $.ajax({
                        url: base_url + 'home/prefix', // URL tujuan
                        type:"POST", 
                        dataType:"json", 
                        success:function(t){ 
                            "1"==t.status?($(".msg-prefix").html(t.msg)):$(".msg-prefix").html(t.msg);
                        }
                    }); 
                })
                
                $(".btn-decode").click(function(){
                    alert('Dalam Pengembanan :)');
                });
                
                $(".symbol").keyup(function(){
                    var t=$(this),n=$(this).val();
                    //console.log(n)
                    n.length>=0&&t.val(function(){
                        return console.log(n.substr(0,20)),n.substr(0,20)
                    }),
                    $.ajax({
                        url: base_url + 'home/check_symbol', // URL tujuan
                        type:"POST", 
                        data:{
                            data:n 
                        },
                        dataType:"json", 
                        success:function(t){
                            console.log(t.status);
                        },
                        error: function(xhr, status, error) {
                            console.log(error);
                        }
                        //"1"==t.status?($(".input-password").html(t.html),$("#password").focus()):$(".input-password").html("")}
                    });
                });
            });
        </script>
        <script src="<?= base_url(); ?>resource/plugins/highlight/highlight.pack.js"></script>
        <script src="<?= base_url(); ?>resource/assets/js/custom.js"></script>
        <!-- END GLOBAL MANDATORY SCRIPTS -->

        <!-- BEGIN PAGE LEVEL CUSTOM SCRIPTS -->
        <script src="<?= base_url(); ?>resource/assets/js/scrollspyNav.js"></script> 
    </body>
</html>