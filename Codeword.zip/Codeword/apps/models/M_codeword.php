<?php

class M_codeword extends CI_Model {

    public function get_data() {
        $sql = "SELECT * FROM coder ORDER BY LENGTH(`codeword`),codeword ASC";
        $query = $this->db->query($sql);
        if ($query->num_rows() > 0) {
            $result = $query->result_array();
            $query->free_result();
            return $result;
        } else {
            return array();
        }
    }
    
    public function get_symbol($param) {
        $sql = "SELECT COUNT(*)'total' FROM coder WHERE BINARY symbol = ?";
        $query = $this->db->query($sql, $param);
        if ($query->num_rows() > 0) {
            $result = $query->row_array();
            $query->free_result();
            return $result['total'];
        } else {
            return array();
        }
    }
    
    public function get_codeword($param){
        $sql = "SELECT * FROM coder WHERE symbol = ?";
        $query = $this->db->query($sql, $param);
        if ($query->num_rows() > 0) {
            $result = $query->row_array();
            $query->free_result();
            return $result;
        } else {
            return array();
        }
    }


    public function check_symbol($val){
        $sql= $this->db->where("BINARY symbol ='".$val."'", NULL, FALSE)
                        ->get('coder');
        return $sql->num_rows();
    }


    public function insert($param){
        $sql = "INSERT INTO coder (symbol,codeword) VALUES (?,?)";
        return $this->db->query($sql, $param);
    }
    
    public function delete_all(){
        $sql= "TRUNCATE coder";
        return $this->db->query($sql);
    }
    
    public function check_prefix($var){ 
        $sql= "SELECT COUNT(*)'total' FROM coder WHERE SUBSTR(codeword,1, ?) = ? ORDER BY codeword ASC";
        $query = $this->db->query($sql, $var);
        if ($query->num_rows() > 0) {
            $result = $query->row_array();
            $query->free_result();
            return $result['total'];
        } else {
            return array();
        }
    }
    
     

}

