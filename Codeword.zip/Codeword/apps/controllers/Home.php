<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {

    public $vars;

    public function __construct() {
        parent::__construct();
        $this->load->model('M_codeword');
    }

    public function index() {
        $html = "";
        $tot = 0;
        $row = 0;
        $result = $this->M_codeword->get_data();
        if ($result) {
            foreach ($result as $val) {
                $tot = $tot + strlen(trim($val['codeword']));
                $row = $row + 1;
                $html .='<tr>';
                $html .='<td><input type ="checkbox"></td>';
                $html .='<td>' . $row . '</td>';
                $html .='<td>' . $val['symbol'] . '</td>';
                $html .='<td>' . $val['codeword'] . '</td>';
                $html .='<td class="text-center">' . strlen(trim($val['codeword'])) . '</td>';
                $html .='</tr>';
            }
            $rata = $tot / $row;
            $this->vars['avg'] = '<tr><th colspan="4">Panjang rata-rata Codeword [' . $tot . '/' . $row . ']</th><th class="text-center">' . $rata . '</th></tr>';
        } else {
            $html = '<tr><th colspan="5" class ="text-center">Data belum terisi</th></tr>';
            $this->vars['html'] = $html;
            $this->vars['avg'] = '';
        }

        $this->vars['result'] = $html;
        $this->load->view('apps/home', $this->vars);
    }

    public function check_symbol() {
        if ($this->input->is_ajax_request()) {
            $this->form_validation->set_rules('symbol', 'Symbol', 'required');
            if ($this->form_validation->run() != FALSE) {
                //$symbol = $this->input->post('data');
                $symbol = 'm';

                $result = $this->M_codeword->check_symbol($symbol);
                if ($result > 0) {
                    $response['status'] = 0;
                    $response['pesan'] = 'Not Available';
                } else {
                    $response['status'] = 1;
                    $response['pesan'] = 'Available';
                }

                $this->json_output($response);

                //$response['status'] = $this->check_symbol($symbol);
            }
        }
    }

    public function save() {
        $this->form_validation->set_rules('symbol', 'Symbol', 'required');
        $this->form_validation->set_rules('binery', 'Binary', 'required');

        if ($this->form_validation->run() != FALSE) {
            $params = array($this->input->post('symbol'), $this->input->post('binery'));
            $this->M_codeword->insert($params);
        } else {
            echo "error";
        }
        redirect('home');
    }

    public function delete_all() {
        $this->M_codeword->delete_all();
        redirect('home');
    }

    public function prefix() {
        $result = $this->M_codeword->get_data();
//        foreach ($result as $rs) {
//            $la = strlen(trim($rs['codeword']));
//            $cc = $this->M_codeword->check_prefix(array($la, $rs['codeword']));
//
//            $j = $cc > 1 ? $j = 0 : $j = 1;
//            if ($cc > 1) {
//                echo "<br >";
//                echo "no prefix-free - " . $rs['codeword'];
//            } else {
//                echo "<br >";
//                echo "yes prefix-free - " . $rs['codeword'];
//            }
//        }

        foreach ($result as $rs) {
            $la = strlen(trim($rs['codeword']));
            $cc = $this->M_codeword->check_prefix(array($la, $rs['codeword']));
            $jk = $cc > 1 ? 'NO' : 'YES';
            $rx[] = $jk == 'NO' ? 'NO' : 'YES';
        }
        if (in_array('NO', $rx)) {
            $response['status'] = 0;
            $response['msg'] = "NO Prefix-Free";
        } else {
            $response['status'] = 1;
            $response['msg'] = "Yes Prefix-Free";
        }

        $this->json_output($response);
    }

    public function entry() {
        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
            if ($this->input->post('save') === 'encode') {
                $this->_encode();
            } else {
                $this->_decode();
            }
        } else {
            $html = '<tr><th colspan="3" class ="text-center">No Result</th></tr>';
            $this->vars['html'] = $html;
            $this->vars['temp'] = "";
            $this->load->view('apps/entry', $this->vars);
        }
    }

    private function _encode() {
        $val = $this->input->post('data');
        $data = str_split($val);

        $html = "";
        $temp = "";
        $tot = 0;
        foreach ($data as $rs) {
            $result = $this->M_codeword->get_symbol($rs);

            if ($result == 0) {
                $temp .='<tr><td colspan="2">Gagal diproses. String "' . $rs . '" belum diinput binary</td></tr>';
                $tot = $tot + 1;
            }
            if ($tot <= 0) {
                $code = $this->M_codeword->get_codeword($rs);
                $html .='<tr>';
                $html .='<td>' . $code['symbol'] . '</td>';
                $html .='<td>' . $code['codeword'] . '</td>';
                $html .='</tr>';
                $decode[] = $code;
            }
        }

        if ($tot <= 0) {
            $temp .='<tr><th colspan="2">String yang dientry: ' . $val . '</th></tr>';
            $temp .='<tr><th colspan="2">Encoder: ';
            foreach ($decode as $key) {
                $temp .= $key['codeword'] . " ";
            }
            $temp .= '</th></tr>';
            $temp .='<tr><th colspan="2">';
            $temp .='<button class="btn-decode btn btn-primary">Decode</button>';
            $temp .='<input type="hidden" name="data" value="' . $val . '"></th></tr>';
            $temp .='<tr><th colspan="2">Decoder:-</th></tr>';
        }
        $this->vars['temp'] = $temp;
        $this->vars['html'] = $html;
        $this->load->view('apps/entry', $this->vars);
    }

    private function _decode() {
        $this->load->view('apps/entry');
    }

    public function json_output($parm, $header = 200) {
        $this->output
                ->set_status_header($header)
                ->set_content_type('application/json', 'utf-8')
                ->set_output(json_encode($parm, JSON_HEX_APOS | JSON_HEX_QUOT))
                ->_display();
        exit();
    }

}